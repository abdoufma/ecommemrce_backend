//@ts-check
"use strict";

// fs est un module qui conotient des fonctions utiles pour la manpulation des fichiers
const fs = require("fs");
const express = require("express");
const multer = require("multer");
const session = require('express-session')
const path = require("path");
const db = require("./db");
const hbs = require("hbs");
const { randomBytes } = require("crypto");
const { extname, basename } = require("path");


const PORT = 80;
const baseUrl = path.join(__dirname, 'public');
const uploadDir = path.join(__dirname, 'public/images');


const app = express();

const sessionConfig = {
    secret: 'mypassword',
    resave: false,
    saveUninitialized: true,
    cookie: {maxAge : 1000 * 3600 * 24}
};

const generate_filename = (file) => randomBytes(24).toString('hex') + extname(file.originalname);

const storage = multer.diskStorage({
    destination:function(req, file, cb){cb(null, uploadDir);},
    filename: function(req, file, cb){cb(null, generate_filename(file));}
});
  


const upload = multer({storage});

app.use(express.urlencoded({ extended: true}));
app.use(express.json());
app.use(session(sessionConfig));
app.use(express.static(baseUrl));

//app.use(express.static(baseUrl));




app.set('view engine', 'html');
app.set('views', baseUrl);
app.engine('html', hbs.__express);


app.get("/", (req, res) => {
    const filePath = path.join(baseUrl, "index.html");
    const html_content = fs.readFileSync(filePath).toString();
    res.send(html_content);
});


app.get("/catalog", async (req, res) => {
    if(req.session.user_id){
        const user = await db.select("id, name, email,password,photo, favs", "users", {id : req.session.user_id}, "row");
        // console.log(user);
        res.render("catalog", {user : JSON.stringify(user)});
    }else{
        res.redirect("/login");
    }
});



app.get("/product/:id", async (req, res) => {
    const {id} = req.params;
    const [product] = await db.select("*", "products", {id});
    if(product){
        res.render("product", product);
    }else{
        res.status(404).send("<h2>Error 404 : Page not found</h2>");
    }
});



app.get("/login", (req, res) => {
    // console.log({"current_user": req.session.user_id});
    res.render("login");
});


app.post(`/uploads`, upload.single('file'), (req, res, next) => {
	console.log('uploading....');
	if(req.file){
        console.log(req.file);
		const file_name = req.file.filename;
        //console.log(file_name);
		res.json({file_name});
	}else{
        console.log("OOOOPS");
    }
});


app.post("/load_products", async(req, res) => {
    const products = await db.select("*", "products",{category:1});
    res.send(products);
});


app.post("/load_products_watc", async(req, res) => {    
    const products = await db.select("*", "products",{category:2});
    res.send(products);
});


app.post("/load_users", async(req, res) => {
    const users = await db.select("*", "users");    
    res.send(users);
});


// endpoint = point de communication

app.post("/save_user", async(req, res) => {
    const {user} = req.body;
    await db.update("users", user, {id : user.id});
    res.end();
});


app.post('/login', async  (req, res) => {
    const {user} = req.body;
    const existingUser = await db.select("*", "users", {email : user.email, password : user.password}, "row");
    if(existingUser){
        req.session["user_id"] = existingUser.id;

        res.send({success: true});
    }else{
        res.send({error : "User not found!"});
    }
});




app.post('/signup', async  (req, res) => {
    const {user} = req.body;
    console.log(user);
    const existingUser = await db.select("*", "users", {email : user.email}, "row");
    if(existingUser){
        res.send({error : "User already exists!"});
    }else{
        await db.insert("users", {...user, favs : "[]"});
        res.send("ok");
    }
});


function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

app.listen(PORT, () => console.log(`server is listening on port ${PORT}` ));


